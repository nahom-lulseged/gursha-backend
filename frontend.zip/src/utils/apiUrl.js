// export const apiUrl = 'https://gursha-delivery.onrender.com';
export const apiUrl = 'http://localhost:3000';